#!/usr/bin/env python3
"""
02 - Enumeración pasiva de subdominios vía crt.sh
Uso: python 02_subdomain_enum.py --domain target.com
"""
import argparse
import json
import urllib.request
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import Fore, Style, init

init(autoreset=True)

CRT_SH_URL = "https://crt.sh/?q=%25.{}&output=json"

def fetch_crt_sh(domain: str) -> set[str]:
    url = CRT_SH_URL.format(domain)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            subdomains = set()
            for entry in data:
                name = entry.get("name_value", "")
                for n in name.split("\n"):
                    n = n.strip().lower()
                    if n and not n.startswith("*"):
                        subdomains.add(n)
            return subdomains
    except Exception as e:
        print(f"{Fore.RED}[!] crt.sh error: {e}")
        return set()

def resolve_host(host: str) -> str | None:
    import socket
    try:
        return socket.gethostbyname(host)
    except socket.gaierror:
        return None

def main():
    parser = argparse.ArgumentParser(description="Passive Subdomain Enumerator")
    parser.add_argument("--domain", "-d", required=True, help="Root domain (e.g. target.com)")
    parser.add_argument("--resolve", "-r", action="store_true", help="Resolve found subdomains")
    parser.add_argument("--threads", type=int, default=20, help="Threads for resolution")
    args = parser.parse_args()

    print(f"{Fore.CYAN}[*] Querying crt.sh for {args.domain}...")
    subs = fetch_crt_sh(args.domain)
    print(f"{Fore.GREEN}[+] Found {len(subs)} unique subdomains\n")

    if args.resolve:
        print(f"{Fore.CYAN}[*] Resolving...\n")
        with ThreadPoolExecutor(max_workers=args.threads) as ex:
            futures = {ex.submit(resolve_host, s): s for s in sorted(subs)}
            for f in as_completed(futures):
                host = futures[f]
                ip = f.result()
                if ip:
                    print(f"{Fore.GREEN}[+] {host:50} -> {ip}")
                else:
                    print(f"{Fore.RED}[-] {host:50} -> (no resolve)")
    else:
        for s in sorted(subs):
            print(f"{Fore.GREEN}[+] {s}")

if __name__ == "__main__":
    main()
