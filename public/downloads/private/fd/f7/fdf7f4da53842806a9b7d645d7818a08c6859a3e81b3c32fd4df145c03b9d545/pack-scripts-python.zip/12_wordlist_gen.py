#!/usr/bin/env python3
"""
12 - Generador de wordlists personalizadas
Uso: python 12_wordlist_gen.py --keywords john,doe,1990,company --depth 3 --out custom.txt
"""
import argparse
import itertools
from pathlib import Path
from colorama import Fore, init

init(autoreset=True)

SEPARATORS = ["", "_", "-", ".", "123", "2024", "2025", "!"]
SUFFIXES = ["", "123", "1234", "2024", "2025", "!", "@", "#"]
PREFIXES = ["", "the", "my", "user"]

def generate_wordlist(keywords: list[str], depth: int) -> set[str]:
    words = set()
    # Combinations of 1 to `depth` keywords
    for d in range(1, depth + 1):
        for combo in itertools.permutations(keywords, d):
            for sep in SEPARATORS:
                base = sep.join(combo)
                for pre in PREFIXES:
                    for suf in SUFFIXES:
                        w = (pre + base + suf) if pre else (base + suf)
                        words.add(w)
                        words.add(w.capitalize())
                        words.add(w.upper())
                        words.add(w.lower())
    return words

def main():
    parser = argparse.ArgumentParser(description="Custom Wordlist Generator")
    parser.add_argument("--keywords", "-k", required=True, help="Comma-separated keywords")
    parser.add_argument("--depth", "-d", type=int, default=2, help="Max permutation depth")
    parser.add_argument("--out", "-o", default="wordlist.txt", help="Output file")
    args = parser.parse_args()

    keywords = [k.strip() for k in args.keywords.split(",") if k.strip()]
    print(f"{Fore.CYAN}[*] Keywords: {keywords}")
    print(f"{Fore.CYAN}[*] Depth: {args.depth}\n")

    wordlist = generate_wordlist(keywords, args.depth)
    print(f"{Fore.GREEN}[+] Generated {len(wordlist):,} unique words")

    with open(args.out, "w") as f:
        for w in sorted(wordlist):
            f.write(w + "\n")
    print(f"{Fore.GREEN}[+] Saved to: {args.out}")

if __name__ == "__main__":
    main()
