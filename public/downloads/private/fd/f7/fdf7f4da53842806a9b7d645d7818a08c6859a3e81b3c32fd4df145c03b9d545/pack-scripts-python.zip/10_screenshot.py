#!/usr/bin/env python3
"""
10 - Screenshot de URLs con Playwright
Uso: python 10_screenshot.py urls.txt --out screenshots/
"""
import argparse
import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
from colorama import Fore, init

init(autoreset=True)

async def screenshot_url(browser, url: str, out_path: Path, wait_ms: int = 2000):
    context = await browser.new_context(viewport={"width": 1280, "height": 800})
    page = await context.new_page()
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=15000)
        await page.wait_for_timeout(wait_ms)
        safe_name = url.replace("https://", "").replace("http://", "").replace("/", "_").replace("?", "_")[:80]
        target = out_path / f"{safe_name}.png"
        await page.screenshot(path=str(target), full_page=False)
        print(f"{Fore.GREEN}[+] {url} -> {target.name}")
    except Exception as e:
        print(f"{Fore.RED}[-] {url} -> {e}")
    finally:
        await context.close()

async def main_async(args):
    out_path = Path(args.out)
    out_path.mkdir(parents=True, exist_ok=True)

    with open(args.urls) as f:
        urls = [line.strip() for line in f if line.strip() and not line.startswith("#")]

    print(f"{Fore.CYAN}[*] Screenshots: {len(urls)} URLs\n")
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        for url in urls:
            if not url.startswith(("http://", "https://")):
                url = "https://" + url
            await screenshot_url(browser, url, out_path, args.wait)
        await browser.close()

def main():
    parser = argparse.ArgumentParser(description="URL Screenshot Tool")
    parser.add_argument("urls", help="File with one URL per line")
    parser.add_argument("--out", "-o", default="screenshots", help="Output dir")
    parser.add_argument("--wait", "-w", type=int, default=2000, help="Wait ms after load")
    args = parser.parse_args()
    asyncio.run(main_async(args))

if __name__ == "__main__":
    main()
