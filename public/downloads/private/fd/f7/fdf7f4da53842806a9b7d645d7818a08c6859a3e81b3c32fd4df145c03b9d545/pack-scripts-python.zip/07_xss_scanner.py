#!/usr/bin/env python3
"""
07 - Detector básico de XSS reflejado
Uso: python 07_xss_scanner.py "https://target.com/search?q=test"
"""
import sys
import urllib.request
import urllib.parse
from colorama import Fore, init

init(autoreset=True)

PAYLOADS = [
    "<script>alert(1)</script>",
    "\<script\>alert(1)\</script\>",
    "\"><script>alert(1)</script>",
    "javascript:alert(1)",
    "<img src=x onerror=alert(1)>",
    "<svg onload=alert(1)>",
    "\'\"><script>alert(1)</script>",
    "<body onload=alert(1)>",
]

def scan_xss(url: str):
    parsed = urllib.parse.urlparse(url)
    if not parsed.query:
        print(f"{Fore.RED}[!] URL must have query parameters")
        return

    params = urllib.parse.parse_qs(parsed.query)
    base_url = urllib.parse.urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", ""))
    
    print(f"{Fore.CYAN}[*] Target: {url}")
    print(f"{Fore.CYAN}[*] Parameters: {list(params.keys())}\n")

    found_count = 0
    for param in params:
        for payload in PAYLOADS:
            test_params = dict(params)
            test_params[param] = [payload]
            test_query = urllib.parse.urlencode(test_params, doseq=True)
            test_url = f"{base_url}?{test_query}"
            try:
                req = urllib.request.Request(test_url, headers={"User-Agent": "Mozilla/5.0 (XssScanner)"})
                with urllib.request.urlopen(req, timeout=10) as resp:
                    body = resp.read().decode("utf-8", errors="ignore")
                    if payload in body:
                        # Check if payload is reflected unescaped
                        clean_payload = payload.replace("\\", "")
                        if clean_payload in body:
                            print(f"{Fore.RED}[!!!] REFLECTED XSS")
                            print(f"    Param:   {param}")
                            print(f"    Payload: {payload}")
                            found_count += 1
                            break
            except Exception:
                continue

    if found_count == 0:
        print(f"{Fore.YELLOW}[-] No reflected XSS detected")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python 07_xss_scanner.py <url-with-params>")
        sys.exit(1)
    scan_xss(sys.argv[1])
