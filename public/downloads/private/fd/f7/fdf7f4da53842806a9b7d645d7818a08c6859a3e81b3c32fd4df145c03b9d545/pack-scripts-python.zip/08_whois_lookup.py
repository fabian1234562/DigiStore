#!/usr/bin/env python3
"""
08 - Lookup WHOIS enriquecido
Uso: python 08_whois_lookup.py target.com
"""
import sys
import whois
from datetime import datetime
from colorama import Fore, init

init(autoreset=True)

def format_date(date_str):
    if isinstance(date_str, list):
        date_str = date_str[0] if date_str else None
    if isinstance(date_str, datetime):
        days_ago = (datetime.now() - date_str).days
        return f"{date_str.strftime('%Y-%m-%d')} ({days_ago}d ago)"
    return str(date_str)

def lookup(domain: str):
    print(f"{Fore.CYAN}[*] WHOIS lookup: {domain}\n")
    try:
        data = whois.whois(domain)
    except Exception as e:
        print(f"{Fore.RED}[!] Error: {e}")
        return

    fields = [
        ("Domain name",      data.domain_name),
        ("Registrar",        data.registrar),
        ("Created",          data.creation_date),
        ("Updated",          data.updated_date),
        ("Expires",          data.expiration_date),
        ("Status",           data.status),
        ("Name servers",     data.name_servers),
        ("Registrant",       data.name),
        ("Organization",     data.org),
        ("Country",          data.country),
        ("Emails",           data.emails),
    ]

    for label, value in fields:
        if value:
            if isinstance(value, list):
                value = ", ".join(str(v) for v in value)
            if label in ("Created", "Updated", "Expires"):
                value = format_date(value)
            print(f"{Fore.GREEN}{label + ':':18} {value}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python 08_whois_lookup.py <domain>")
        sys.exit(1)
    lookup(sys.argv[1])
