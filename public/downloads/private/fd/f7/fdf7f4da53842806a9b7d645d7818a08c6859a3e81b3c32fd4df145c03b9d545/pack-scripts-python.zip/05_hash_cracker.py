#!/usr/bin/env python3
"""
05 - Crackeador de hashes con wordlist (MD5, SHA1, SHA256)
Uso: python 05_hash_cracker.py --hash 5f4dcc3b5aa765d61d8327deb882cf99 --type md5 --wordlist rockyou.txt
"""
import argparse
import hashlib
from colorama import Fore, init

init(autoreset=True)

HASHERS = {
    "md5":    hashlib.md5,
    "sha1":   hashlib.sha1,
    "sha256": hashlib.sha256,
    "sha512": hashlib.sha512,
}

def hash_word(word: str, algorithm: str) -> str:
    return HASHERS[algorithm](word.encode("utf-8")).hexdigest()

def main():
    parser = argparse.ArgumentParser(description="Dictionary hash cracker")
    parser.add_argument("--hash", "-H", required=True, help="Hash to crack")
    parser.add_argument("--type", "-t", required=True, choices=list(HASHERS.keys()), help="Hash algorithm")
    parser.add_argument("--wordlist", "-w", required=True, help="Wordlist file")
    args = parser.parse_args()

    target = args.hash.lower().strip()
    print(f"{Fore.CYAN}[*] Cracking {args.type} hash: {target}")
    print(f"{Fore.CYAN}[*] Wordlist: {args.wordlist}\n")

    try:
        with open(args.wordlist, errors="ignore") as f:
            for i, line in enumerate(f, 1):
                word = line.rstrip("\n\r")
                h = hash_word(word, args.type)
                if h == target:
                    print(f"{Fore.GREEN}[+] FOUND after {i} attempts!")
                    print(f"{Fore.GREEN}    Hash:   {target}")
                    print(f"{Fore.GREEN}    Plain:  {word}")
                    return
                if i % 100000 == 0:
                    print(f"{Fore.YELLOW}[*] Tried {i} words...")
    except FileNotFoundError:
        print(f"{Fore.RED}[!] Wordlist not found: {args.wordlist}")
        return

    print(f"{Fore.RED}[-] Hash not found in wordlist (tried {i} words)")

if __name__ == "__main__":
    main()
