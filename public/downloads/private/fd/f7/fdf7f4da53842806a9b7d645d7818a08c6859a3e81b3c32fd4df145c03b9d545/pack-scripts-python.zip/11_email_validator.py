#!/usr/bin/env python3
"""
11 - Valida email sin enviar (formato + MX + SMTP RCPT TO)
Uso: python 11_email_validator.py user@example.com
"""
import sys
import re
import smtplib
import dns.resolver
from colorama import Fore, init

init(autoreset=True)

EMAIL_RE = re.compile(r"^[a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+$")

def get_mx_records(domain: str) -> list:
    try:
        answers = dns.resolver.resolve(domain, "MX")
        return sorted([(r.preference, str(r.exchange).rstrip(".")) for r in answers])
    except Exception:
        return []

def smtp_check(email: str, mx_host: str) -> tuple[bool, str]:
    try:
        with smtplib.SMTP(timeout=10) as server:
            server.connect(mx_host)
            server.ehlo("digistore.com")
            server.mail("verify@digistore.com")
            code, msg = server.rcpt(email)
            return code == 250, f"{code} {msg.decode() if isinstance(msg, bytes) else msg}"
    except Exception as e:
        return False, str(e)

def validate(email: str):
    print(f"{Fore.CYAN}[*] Validating: {email}\n")

    if not EMAIL_RE.match(email):
        print(f"{Fore.RED}[!] Invalid format")
        return False

    domain = email.rsplit("@", 1)[1]
    print(f"{Fore.GREEN}[+] Format: valid")
    print(f"{Fore.GREEN}[+] Domain: {domain}")

    mx_records = get_mx_records(domain)
    if not mx_records:
        print(f"{Fore.RED}[!] No MX records found - domain cannot receive email")
        return False

    print(f"{Fore.GREEN}[+] MX records: {len(mx_records)}")
    for pref, host in mx_records[:3]:
        print(f"        {pref:3}  {host}")

    if not args.skip_smtp:
        _, mx_host = mx_records[0]
        ok, msg = smtp_check(email, mx_host)
        if ok:
            print(f"{Fore.GREEN}[+] SMTP check: mailbox exists")
        else:
            print(f"{Fore.YELLOW}[!] SMTP check: {msg}")
    return True

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python 11_email_validator.py <email> [--skip-smtp]")
        sys.exit(1)

    args = type("Args", (), {"skip_smtp": "--skip-smtp" in sys.argv})()
    email = sys.argv[1]
    validate(email)
