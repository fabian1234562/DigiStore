# Pack de Scripts Python para Hacking Ético

> **DigiStore — Uso personal. No redistribuir.**

Este pack contiene 12 scripts Python listos para usar en pentests y auditorías.
Requisitos: Python 3.10+. Instala dependencias con:

```bash
pip install -r requirements.txt
```

## ⚠️ Aviso legal

Estos scripts son para uso educativo y profesional en sistemas donde tienes
autorización escrita. El uso sin consentimiento es ilegal.

## Scripts incluidos

| Script | Descripción |
|--------|-------------|
| 01_port_scanner.py | Escáner de puertos TCP multihilo |
| 02_subdomain_enum.py | Enumeración pasiva de subdominios vía crt.sh |
| 03_dir_bruter.py | Fuerza bruta de directorios web con wordlist |
| 04_http_header_check.py | Audita headers de seguridad HTTP |
| 05_hash_cracker.py | Crackeador de hashes MD5/SHA1/SHA256 con wordlist |
| 06_sql_injection_scanner.py | Detector básico de SQLi en parámetros URL |
| 07_xss_scanner.py | Detector básico de XSS reflejado |
| 08_whois_lookup.py | Lookup WHOIS enriquecido para dominios |
| 09_dns_enum.py | Enumeración DNS completa (A, MX, TXT, NS, CNAME) |
| 10_screenshot.py | Screenshot de URLs con Playwright |
| 11_email_validator.py | Valida email sin enviar (SMTP check + Holes) |
| 12_wordlist_gen.py | Generador de wordlists personalizadas |

## Uso rápido

```bash
# Escanear puertos comunes
python 01_port_scanner.py --target example.com --ports 1-1000

# Enumerar subdominios
python 02_subdomain_enum.py --domain target.com

# Brute-force de directorios
python 03_dir_bruter.py --url https://target.com --wordlist common.txt

# Auditar headers HTTP
python 04_http_header_check.py https://target.com
```

## Soporte

¿Problemas? Contacta soporte@digistore.com
