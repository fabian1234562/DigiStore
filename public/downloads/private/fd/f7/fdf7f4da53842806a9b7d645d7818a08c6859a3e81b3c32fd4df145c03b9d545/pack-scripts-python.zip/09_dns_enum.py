#!/usr/bin/env python3
"""
09 - Enumeración DNS completa
Uso: python 09_dns_enum.py target.com
"""
import sys
import dns.resolver
from colorama import Fore, init

init(autoreset=True)

RECORD_TYPES = ["A", "AAAA", "MX", "TXT", "NS", "CNAME", "SOA", "CAA"]

def enumerate_dns(domain: str):
    print(f"{Fore.CYAN}[*] DNS enumeration for: {domain}\n")
    resolver = dns.resolver.Resolver()
    resolver.timeout = 5
    resolver.lifetime = 10

    for rtype in RECORD_TYPES:
        try:
            answers = resolver.resolve(domain, rtype)
            print(f"{Fore.GREEN}[+] {rtype:6} records:")
            for rdata in answers:
                print(f"        {rdata.to_text()}")
        except dns.resolver.NoAnswer:
            pass
        except dns.resolver.NXDOMAIN:
            print(f"{Fore.RED}[-] {rtype:6} -> Domain does not exist")
            return
        except dns.resolver.NoNameservers:
            print(f"{Fore.YELLOW}[!] {rtype:6} -> No nameservers responded")
        except Exception as e:
            pass

    # Also try DMARC
    try:
        answers = resolver.resolve(f"_dmarc.{domain}", "TXT")
        print(f"\n{Fore.GREEN}[+] DMARC record:")
        for rdata in answers:
            print(f"        {rdata.to_text()}")
    except Exception:
        print(f"\n{Fore.YELLOW}[!] DMARC not configured")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python 09_dns_enum.py <domain>")
        sys.exit(1)
    enumerate_dns(sys.argv[1])
