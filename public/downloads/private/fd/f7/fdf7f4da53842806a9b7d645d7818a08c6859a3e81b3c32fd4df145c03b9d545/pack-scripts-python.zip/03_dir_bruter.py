#!/usr/bin/env python3
"""
03 - Fuerza bruta de directorios web con wordlist
Uso: python 03_dir_bruter.py --url https://target.com --wordlist common.txt
"""
import argparse
import urllib.request
import urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed
from colorama import Fore, init

init(autoreset=True)

FOUND_CODES = {200, 201, 204, 301, 302, 307, 401, 403, 405}

def check_path(base_url: str, path: str, timeout: float = 5.0) -> tuple[str, int, str]:
    url = base_url.rstrip("/") + "/" + path.strip("/")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (DirBruter)"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            length = len(resp.read(2048))
            return url, resp.status, f"{length}B"
    except urllib.error.HTTPError as e:
        return url, e.code, ""
    except Exception as e:
        return url, 0, str(e)[:40]

def main():
    parser = argparse.ArgumentParser(description="Directory Brute-Forcer")
    parser.add_argument("--url", "-u", required=True, help="Base URL")
    parser.add_argument("--wordlist", "-w", required=True, help="Wordlist file")
    parser.add_argument("--threads", "-t", type=int, default=20)
    parser.add_argument("--extensions", "-e", default="", help="Comma-separated extensions (php,html,txt)")
    args = parser.parse_args()

    try:
        with open(args.wordlist) as f:
            paths = [line.strip() for line in f if line.strip() and not line.startswith("#")]
    except FileNotFoundError:
        print(f"{Fore.RED}[!] Wordlist not found: {args.wordlist}")
        return

    extensions = [e.strip() for e in args.extensions.split(",") if e.strip()]
    full_paths = []
    for p in paths:
        full_paths.append(p)
        for ext in extensions:
            full_paths.append(f"{p}.{ext}")

    print(f"{Fore.CYAN}[*] Testing {len(full_paths)} paths on {args.url}\n")

    found = []
    with ThreadPoolExecutor(max_workers=args.threads) as ex:
        futures = {ex.submit(check_path, args.url, p): p for p in full_paths}
        for f in as_completed(futures):
            url, code, info = f.result()
            if code in FOUND_CODES:
                print(f"{Fore.GREEN}[{code}] {url}  ({info})")
                found.append((url, code))

    print(f"\n{Fore.CYAN}[*] Found {len(found)} paths with response.")

if __name__ == "__main__":
    main()
