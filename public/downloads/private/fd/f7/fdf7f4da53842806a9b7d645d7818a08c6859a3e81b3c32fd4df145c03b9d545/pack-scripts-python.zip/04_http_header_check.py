#!/usr/bin/env python3
"""
04 - Audita headers de seguridad HTTP
Uso: python 04_http_header_check.py https://target.com
"""
import sys
import urllib.request
from colorama import Fore, init

init(autoreset=True)

REQUIRED_HEADERS = {
    "strict-transport-security": ("HSTS - protege contra downgrade attacks", "high"),
    "content-security-policy":   ("CSP - previene XSS y data injection", "high"),
    "x-frame-options":           ("Clickjacking protection", "medium"),
    "x-content-type-options":    ("MIME sniffing protection", "medium"),
    "referrer-policy":           ("Control de información en Referer", "low"),
    "permissions-policy":        ("Control de features del navegador", "low"),
}

def audit(url: str):
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    print(f"{Fore.CYAN}[*] Auditing: {url}\n")
    try:
        req = urllib.request.Request(url, method="GET", headers={"User-Agent": "Mozilla/5.0 (HeaderCheck)"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            headers = {k.lower(): v for k, v in resp.headers.items()}
    except Exception as e:
        print(f"{Fore.RED}[!] Error: {e}")
        return

    print(f"{Fore.CYAN}[+] Server: {headers.get('server', 'unknown')}")
    print(f"{Fore.CYAN}[+] X-Powered-By: {headers.get('x-powered-by', 'hidden')}\n")

    print(f"{Fore.YELLOW}=== Security Headers ===")
    for header, (desc, severity) in REQUIRED_HEADERS.items():
        if header in headers:
            print(f"{Fore.GREEN}[+] {header}: present  ({desc})")
        else:
            color = Fore.RED if severity == "high" else Fore.YELLOW if severity == "medium" else Fore.WHITE
            print(f"{color}[-] {header}: MISSING  ({desc})")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python 04_http_header_check.py <url>")
        sys.exit(1)
    audit(sys.argv[1])
