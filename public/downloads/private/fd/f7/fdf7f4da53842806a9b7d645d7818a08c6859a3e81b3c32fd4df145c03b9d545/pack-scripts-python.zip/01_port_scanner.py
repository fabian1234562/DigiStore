#!/usr/bin/env python3
"""
01 - Escáner de puertos TCP multihilo
Uso: python 01_port_scanner.py --target example.com --ports 1-1000
"""
import argparse
import socket
import concurrent.futures
from datetime import datetime
from colorama import Fore, Style, init

init(autoreset=True)

def scan_port(host: str, port: int, timeout: float = 1.0) -> tuple[int, bool, str]:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(timeout)
            result = s.connect_ex((host, port))
            if result == 0:
                try:
                    service = socket.getservbyport(port, "tcp")
                except OSError:
                    service = "unknown"
                return port, True, service
    except Exception:
        pass
    return port, False, ""

def parse_ports(ports_str: str) -> list[int]:
    if "-" in ports_str:
        start, end = map(int, ports_str.split("-"))
        return list(range(start, end + 1))
    return [int(p) for p in ports_str.split(",")]

def main():
    parser = argparse.ArgumentParser(description="TCP Port Scanner")
    parser.add_argument("--target", "-t", required=True, help="Host or IP")
    parser.add_argument("--ports", "-p", default="1-1024", help="Port range (e.g. 1-1000 or 22,80,443)")
    parser.add_argument("--timeout", type=float, default=1.0, help="Socket timeout in seconds")
    parser.add_argument("--threads", type=int, default=100, help="Max concurrent threads")
    args = parser.parse_args()

    try:
        ip = socket.gethostbyname(args.target)
    except socket.gaierror:
        print(f"{Fore.RED}[!] Cannot resolve {args.target}")
        return

    ports = parse_ports(args.ports)
    print(f"{Fore.CYAN}[*] Scanning {args.target} ({ip}) - {len(ports)} ports")
    print(f"{Fore.CYAN}[*] Started at {datetime.now().strftime('%H:%M:%S')}\n")

    open_ports = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.threads) as ex:
        futures = [ex.submit(scan_port, ip, p, args.timeout) for p in ports]
        for f in concurrent.futures.as_completed(futures):
            port, is_open, service = f.result()
            if is_open:
                print(f"{Fore.GREEN}[+] {port}/tcp open  {service}")
                open_ports.append((port, service))

    print(f"\n{Fore.CYAN}[*] Scan finished. {len(open_ports)} open ports.")
    if open_ports:
        print(f"{Fore.YELLOW}[*] Open ports: {', '.join(str(p) for p, _ in open_ports)}")

if __name__ == "__main__":
    main()
