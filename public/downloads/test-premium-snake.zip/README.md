# Snake Premium - DigiStore Test Product

> **Producto de prueba** para auditar el flujo de pago de DigiStore.

## Cómo jugar

1. Abre `index.html` en cualquier navegador web
2. Usa las flechas del teclado o los botones en pantalla
3. Come las manzanas rojas para crecer
4. No choques contra las paredes ni contra ti mismo

## Características

- Juego Snake clásico en HTML5
- Funciona en cualquier navegador (PC, Mac, móvil)
- Guarda tu récord en localStorage
- Sin dependencias externas
- 100% offline una vez descargado

## Información del producto

- **Producto ID**: test-premium-snake
- **Precio**: $0.99 USD (precio de prueba)
- **Formato**: ZIP con HTML + JavaScript
- **Tamaño**: ~5 KB
- **Plataformas**: Cualquiera con navegador web
- **Licencia**: MIT (open source)

---

Este producto existe únicamente para probar que el flujo de compra → pago →
entrega → descarga funcione correctamente en DigiStore.

Si puedes jugar este juego después de pasar por todo el flujo de compra,
significa que el sistema de entrega automática está funcionando.

© DigiStore - Test Product
